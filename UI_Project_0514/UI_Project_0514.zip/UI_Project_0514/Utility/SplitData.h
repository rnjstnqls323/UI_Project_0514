#pragma once

class SplitData
{
public: 
	static vector<string> SplitDatas(string origin, string tok);
};